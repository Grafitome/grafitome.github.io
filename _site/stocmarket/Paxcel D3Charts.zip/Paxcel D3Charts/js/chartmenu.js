$(document).ready(function(){
  $("#basicLineChartMenu").click(function(){
    $("#basicLineChart").show();
	  $("#scatterPlotChart").hide();
	  $("#drillDownChart").hide();
	  $("#heatmap").hide();
	  $("#transitPie").hide();
	  $("#radarChart").hide();
	  $("#multiAxis").hide();
	  $("#groupedBar").hide();
	  $("#3DBarChart").hide();
	  $("#stackedAreaChart").hide();	
	  $("#stackedBarChart").hide();
	  $("#funnelChartMenu").hide();
	  $("#guageGraph").hide();
	  $("#areaChart").hide();
	  $("#pyramidChart").hide();
	  $('#invertPyramid').hide();
	  $('#meterChart').hide();

  });
  $("#scatterPlotChartMenu").click(function(){
    $("#scatterPlotChart").show();
	$("#basicLineChart").hide();
	$("#drillDownChart").hide();
	$("#heatmap").hide();
	$("#transitPie").hide();
	$("#radarChart").hide();
	$("#multiAxis").hide();
	$("#groupedBar").hide();
	$("#3DBarChart").hide();
	$("#stackedAreaChart").hide();
	$("#stackedBarChart").hide();	
	$("#funnelChartMenu").hide();
	$("#guageGraph").hide();
	$("#areaChart").hide();
	$("#pyramidChart").hide();
	$('#invertPyramid').hide();
	$('#meterChart').hide();

  });
  
   $("#drillDownChartMenu").click(function(){
	$("#drillDownChart").show();  
    $("#scatterPlotChart").hide();
	$("#heatmap").hide();
	$("#basicLineChart").hide();
	$("#transitPie").hide();
	$("#radarChart").hide();
	$("#multiAxis").hide();
	$("#groupedBar").hide();
	$("#3DBarChart").hide();	
	$("#stackedAreaChart").hide();
	$("#stackedBarChart").hide();
	$("#funnelChartMenu").hide();
	$("#guageGraph").hide();
	$("#areaChart").hide();
	$("#pyramidChart").hide();
	$('#invertPyramid').hide();
	$('#meterChart').hide();
	

  });
  
  
   $("#heatmapMenu").click(function(){
	$("#heatmap").show();
	$("#drillDownChart").hide();  
    $("#scatterPlotChart").hide();
	$("#basicLineChart").hide();
	$("#transitPie").hide();
	$("#radarChart").hide();
	$("#multiAxis").hide();
	$("#groupedBar").hide();
	$("#3DBarChart").hide();
	$("#stackedAreaChart").hide();	
	$("#stackedBarChart").hide();
	$("#funnelChartMenu").hide();
	$("#guageGraph").hide();
	$("#areaChart").hide();
	$("#pyramidChart").hide();
	$('#invertPyramid').hide();
	$('#meterChart').hide();
	

  });
  
    $("#transitPieMenu").click(function(){
	$("#transitPie").show();
	$("#heatmap").hide();
	$("#drillDownChart").hide();  
    $("#scatterPlotChart").hide();
	$("#basicLineChart").hide();
	$("#radarChart").hide();
    $("#multiAxis").hide();
	$("#groupedBar").hide();
	$("#3DBarChart").hide();
	$("#stackedAreaChart").hide();	
	$("#stackedBarChart").hide();
	$("#funnelChartMenu").hide();
	$("#guageGraph").hide();
	$("#areaChart").hide();
	$("#pyramidChart").hide();
	$('#invertPyramid').hide();
	$('#meterChart').hide();
	

  });
  
    $("#radarChartMenu").click(function(){
	$("#radarChart").show();
	$("#transitPie").hide();
	$("#heatmap").hide();
	$("#drillDownChart").hide();  
    $("#scatterPlotChart").hide();
	$("#basicLineChart").hide();
	$("#multiAxis").hide();
	$("#groupedBar").hide();
	$("#3DBarChart").hide();
	$("#stackedAreaChart").hide();	
	$("#stackedBarChart").hide();
	$("#funnelChartMenu").hide();
	$("#guageGraph").hide();
	$("#areaChart").hide();
	$("#pyramidChart").hide();
	$('#invertPyramid').hide();
	$('#meterChart').hide();
	
	

  });
  
  
    $("#multiAxisMenu").click(function(){
	$("#multiAxis").show();	
	$("#radarChart").hide();
	$("#transitPie").hide();
	$("#heatmap").hide();
	$("#drillDownChart").hide();  
    $("#scatterPlotChart").hide();
	$("#basicLineChart").hide();
	$("#groupedBar").hide();
	$("#3DBarChart").hide();
	$("#stackedAreaChart").hide();
	$("#stackedBarChart").hide();
	$("#funnelChartMenu").hide();
	$("#guageGraph").hide();
	$("#areaChart").hide();
	$("#pyramidChart").hide();
	$('#invertPyramid').hide();
	$('#meterChart').hide();
	
	

  });
  
  
    $("#groupedBarMenu").click(function(){
	$("#groupedBar").show();
	$("#multiAxis").hide();	
	$("#radarChart").hide();
	$("#transitPie").hide();
	$("#heatmap").hide();
	$("#drillDownChart").hide();  
    $("#scatterPlotChart").hide();
	$("#basicLineChart").hide();
	$("#3DBarChart").hide();
	$("#stackedAreaChart").hide();
	$("#stackedBarChart").hide();
	$("#funnelChartMenu").hide();
	$("#guageGraph").hide();
	$("#areaChart").hide();
	$("#pyramidChart").hide();
	$('#invertPyramid').hide();
	$('#meterChart').hide();
	
	  });
	  
	  
	$("#3DBarChartMenu").click(function(){
	$("#3DBarChart").show();	
	$("#groupedBar").hide();
	$("#multiAxis").hide();	
	$("#radarChart").hide();
	$("#transitPie").hide();
	$("#heatmap").hide();
	$("#drillDownChart").hide();  
    $("#scatterPlotChart").hide();
	$("#basicLineChart").hide();
	$("#stackedAreaChart").hide();
	$("#stackedBarChart").hide();
	$("#funnelChartMenu").hide();
	$("#guageGraph").hide();
	$("#areaChart").hide();
	$("#pyramidChart").hide();
	$('#invertPyramid').hide();
	$('#meterChart').hide();
	  });
	  
	$("#stackedAreaChartMenu").click(function(){
	$("#stackedAreaChart").show();
	$("#3DBarChart").hide();		
	$("#groupedBar").hide();
	$("#multiAxis").hide();	
	$("#radarChart").hide();
	$("#transitPie").hide();
	$("#heatmap").hide();
	$("#drillDownChart").hide();  
    $("#scatterPlotChart").hide();
	$("#basicLineChart").hide();
	$("#stackedBarChart").hide();
	$("#funnelChartMenu").hide();
	$("#guageGraph").hide();
	$("#areaChart").hide();
	$("#pyramidChart").hide();
	$('#invertPyramid').hide();
	$('#meterChart').hide();
	
	  });
	  
	$("#stackedBarChartMenu").click(function(){
	$("#stackedBarChart").show();
	$("#stackedAreaChart").hide();
	$("#3DBarChart").hide();		
	$("#groupedBar").hide();
	$("#multiAxis").hide();	
	$("#radarChart").hide();
	$("#transitPie").hide();
	$("#heatmap").hide();
	$("#drillDownChart").hide();  
    $("#scatterPlotChart").hide();
	$("#basicLineChart").hide();
	$("#funnelChartMenu").hide();
	$("#guageGraph").hide();
	$("#areaChart").hide();
	$("#pyramidChart").hide();
	$('#invertPyramid').hide();
	$('#meterChart').hide();
	
	  });
	  
    $("#funnelChartMenu").click(function(){
	$("#funnelChartMenu").show();
	$("#stackedBarChart").hide();
	$("#stackedAreaChart").hide();
	$("#3DBarChart").hide();		
	$("#groupedBar").hide();
	$("#multiAxis").hide();	
	$("#radarChart").hide();
	$("#transitPie").hide();
	$("#heatmap").hide();
	$("#drillDownChart").hide();  
    $("#scatterPlotChart").hide();
	$("#basicLineChart").hide();
	$("#guageGraph").hide();
	$("#areaChart").hide();
	$("#pyramidChart").hide();
	$('#invertPyramid').hide();
	$('#meterChart').hide();
	
	  });
	  
    $("#guageGraphMenu").click(function(){
	$("#guageGraph").show();
	$("#funnelChartMenu").hide();
	$("#stackedBarChart").hide();
	$("#stackedAreaChart").hide();
	$("#3DBarChart").hide();		
	$("#groupedBar").hide();
	$("#multiAxis").hide();	
	$("#radarChart").hide();
	$("#transitPie").hide();
	$("#heatmap").hide();
	$("#drillDownChart").hide();  
    $("#scatterPlotChart").hide();
	$("#basicLineChart").hide();
	$("#areaChart").hide();
	$("#pyramidChart").hide();
	$('#invertPyramid').hide();
	$('#meterChart').hide();
	
	  });
	  
	$("#areaChartMenu").click(function(){
	$("#areaChart").show();
	$("#guageGraph").hide();
	$("#funnelChartMenu").hide();
	$("#stackedBarChart").hide();
	$("#stackedAreaChart").hide();
	$("#3DBarChart").hide();		
	$("#groupedBar").hide();
	$("#multiAxis").hide();	
	$("#radarChart").hide();
	$("#transitPie").hide();
	$("#heatmap").hide();
	$("#drillDownChart").hide();  
    $("#scatterPlotChart").hide();
	$("#basicLineChart").hide();
	$("#pyramidChart").hide();
	$('#invertPyramid').hide();
	$('#meterChart').hide();
	
	  });
	  
	$("#test1").click(function(){
		
	$("#pyramidChart").show();
	$("#areaChart").hide();
	$("#guageGraph").hide();
	$("#funnelChartMenu").hide();
	$("#stackedBarChart").hide();
	$("#stackedAreaChart").hide();
	$("#3DBarChart").hide();		
	$("#groupedBar").hide();
	$("#multiAxis").hide();	
	$("#radarChart").hide();
	$("#transitPie").hide();
	$("#heatmap").hide();
	$("#drillDownChart").hide();  
    $("#scatterPlotChart").hide();
	$("#basicLineChart").hide();
	$('#invertPyramid').hide();
	$('#meterChart').hide();
	
	  });
	  
	$("#invertPyramidMenu").click(function(){
	$('#invertPyramid').show();
	$("#pyramidChart").hide();
	$("#areaChart").hide();
	$("#guageGraph").hide();
	$("#funnelChartMenu").hide();
	$("#stackedBarChart").hide();
	$("#stackedAreaChart").hide();
	$("#3DBarChart").hide();		
	$("#groupedBar").hide();
	$("#multiAxis").hide();	
	$("#radarChart").hide();
	$("#transitPie").hide();
	$("#heatmap").hide();
	$("#drillDownChart").hide();  
    $("#scatterPlotChart").hide();
	$("#basicLineChart").hide();
	$('#meterChart').hide();
	
	  });
	  
	  
	  $("#meterChartMenu").click(function(){
	$('#meterChart').show();
	$('#invertPyramid').hide();
	$("#pyramidChart").hide();
	$("#areaChart").hide();
	$("#guageGraph").hide();
	$("#funnelChartMenu").hide();
	$("#stackedBarChart").hide();
	$("#stackedAreaChart").hide();
	$("#3DBarChart").hide();		
	$("#groupedBar").hide();
	$("#multiAxis").hide();	
	$("#radarChart").hide();
	$("#transitPie").hide();
	$("#heatmap").hide();
	$("#drillDownChart").hide();  
    $("#scatterPlotChart").hide();
	$("#basicLineChart").hide();
	
	  });
	  
	  
  
 $('.chartMenuList ul li a').click(function() {
    $('.chartMenuList ul li.active').removeClass('active');
    $(this).closest('.chartMenuList ul li').addClass('active');
});
  
});

 $('.nav ul li').click(function() {
    $('.multiplechart').addClass('addopacity');
    
});



