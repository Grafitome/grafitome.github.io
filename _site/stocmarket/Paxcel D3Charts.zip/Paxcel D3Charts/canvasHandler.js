
var lastX, lastY;
var ctx;
var pencilcolor="red";
var penStrokeWidth=3;


$(document).ready(function(){

				 function InitThis() {
						//  ctx = document.getElementById('myCanvas').getContext("2d");
						var canvasid='#canvas2';
						ctx = document.getElementById('canvas2').getContext("2d");
						$(canvasid).mousedown(function (e) {
							mousePressed = true;
							Draw(e.pageX - $(this).offset().left, e.pageY - $(this).offset().top, false);
						});

						$(canvasid).mousemove(function (e) {
							if (mousePressed) {
								Draw(e.pageX - $(this).offset().left, e.pageY - $(this).offset().top, true);
							}
						});

						$(canvasid).mouseup(function (e) {
							mousePressed = false;
						});
							$(canvasid).mouseleave(function (e) {
							mousePressed = false;
						});
				}

				function Draw(x, y, isDown) {
						if (isDown) {
							ctx.beginPath();
							ctx.strokeStyle =pencilcolor;// $('#selColor').val();
							ctx.lineWidth =penStrokeWidth;// $('#selWidth').val();
							ctx.lineJoin = "round";
							ctx.moveTo(lastX, lastY);
							ctx.lineTo(x, y);
							ctx.closePath();
							ctx.stroke();
						}
						lastX = x; lastY = y;
				}
					
				function clearArea() {
					// Use the identity matrix while clearing the canvas
					ctx.setTransform(1, 0, 0, 1, 0, 0);
					ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
				}

				InitThis();
					var container = document.getElementById('historicalDataChart');
				   // init(container, 500, 400, 'black');
					
					
					
				


			$('#isEditableArena').click(function() {
				var $this = $(this);
				// $this will contain a reference to the checkbox   
				if ($this.is(':checked')) {
					$('#canvas2').show();
				} else {
						$('#canvas2').hide();
				}
			});
			
			
			
			
			$('#penstrokewidth').change(function() {
			//alert($('select option:selected').val());
				penStrokeWidth=$('select option:selected').val();
			
			});
			
			$('#pencolor').click(function(e){
					$('#colorPicker').unbind('colorchange');
					console.log("offset is:"+$('.beanish-color'));
					$("#colorPicker").jqxColorPicker({
						width: 200,
						height: 180
					});
					$("#colorpickerbox").css('left',e.offSetX +'px');
					$('#colorpickerbox').show();
					$('#colorPicker').bind('colorchange', function (event)
					{ 
						var cCode='#'+$("#colorPicker").jqxColorPicker('getColor').hex;
						$('.fa-pencil-color').css('color',cCode);
						pencilcolor=cCode;
					
					});
			  
			});
			
			$('.clear-editing').click(function(){
				clearArea();
			
			});
			
			















});