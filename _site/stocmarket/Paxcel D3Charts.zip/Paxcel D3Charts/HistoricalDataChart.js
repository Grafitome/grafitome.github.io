angular.module("chartApp").controller("historicalDataChartCtlr", function ($scope,$rootScope){

	var historicalChartWidth;
	var historicalChartHeight;
	var xScaleHistoricChart;
	var yScaleHistoricChart;
	var xAxisHistoricChart;
	var yAxisHistoricChart;
	var historicChartSvg;
	var historicChartMinX;
	var historicChartMaxX;
	var historicChartMinY;
	var historicChartMaxY;
	
	var numbars='250';
	//var startDate='2013-06-10';//getDate('start',1);
	//var endDate='2014-05-10';//getDate('end','')
	var startDate=getDate('start',1,true);
	var endDate=getDate('end','')
	var historicChartData=[];
	var	parseDate = d3.time.format("%Y-%m-%d");
	//var formatDate = d3.time.format("%e-%b-%Y");
	var formatDate = d3.time.format("%e,%b,%Y");
	var closeDataArray;
	var dateArray;
	var demaDataArray;
	var cmfDataArray;
	var margin={right:50,bottom:30,xAxisBottom:3,top:35};
	var	closeLine;
	var demaLine;
	var panningAndZooming;
	var xMinDate;
	var xMaxDate;
	var xMin;
	var xMax;
	var closeDifferenceSvg;
	var closeDifferenceArray=[];
	var scalableLimit=2;
	var yScaleCloseDifference;
	var turningPoints;
	var yScaleCmfChart;
	var subsetCMF=[];	
	var sortOrder = false;
	var area;
	//historicalChartHeight=(historicalChartHeight/2.5);
	function calculateDimension(){
		historicalChartWidth=$('#historicalDataChart').width()-35;
		historicalChartHeight=$('#historicalDataChart').height()*.90-15;
	}
	function initHistoricChart(){
		calculateDimension();
		getHistoricData();
		$scope.drawComparitiveChart();
	}
	initHistoricChart();
	
	$scope.drawHistoricCharts=function(){
		console.log('api called ');
		getHistoricData();
	}
	$rootScope.$on('showHistoricChartForSymbol', function(e,msg,switchSymbol) { 
			console.log("stop chart broadcast event "+msg +" :switch symbol "+switchSymbol);
			if(historicChartData.length == 0){
				return;
			}
			if(msg){
				getHistoricData();
			}
			else{
				drawCharts();
			}
	});
	
	function sortTheBars(a,b,sortByAscending){
		var aClose=a.close;
		var bClose=b.close;
		if(sortByAscending){
			if(!isNaN(a.close) && a.close!=null){
				if(a.close>b.close){
					return 1;
				}
				else if(a.close<b.close){
					return -1;
				}
				else{
					return 0;
				}
			}
			else{
				return 0;
			}
		}
		else{
			if(!isNaN(a.close) && a.close!=null){
				if(a.close>b.close){
					return -1;
				}
				else if(a.close<b.close){
					return 1;
				}
				else{
					return 0;
				}
			}
			else{
				return 0;
			}
		}
	
	}
	$(document).ready(function(){
	//$('.sortButton').click(function(){
			//alert("inSorting");
				
			//});
	});
	
	$(window).resize(function () {
		console.log('window resize ');
		calculateDimension();
		drawCharts();
	});
	var i=0;
	function drawCharts(){
		
		$('#cmf').html('');
		$('#closeDemaChartDiv').html('');
		$('#closePriceDifferenceChartDiv').html('');
		generateXScale();
		if($scope.$parent.areaChart){
			drawCMFChart();
		}
		if($scope.$parent.barChart){
			drawCloseDemaChart();
		}
		if($scope.$parent.candleChart){
			drawCloseDifferenceChart();
		}
		drawXAxis();
		panningAndZooming=d3.behavior.zoom().x(xScaleHistoricChart).scaleExtent([1, 8]).on("zoom", zoom);					
		d3.select('#historicalDataChart').call(panningAndZooming);
		
		i++;
	}
	 $scope.sortBars=function(){
		sortOrder = !sortOrder;
		//alert("sort "+sortOrder);
		sortItems = function (a, b) {
			var sortStatus=0;
			//console.log("sort by "+sortOrder);
		//alert("   "+a+"   "+b);
			if (sortOrder) {
				return sortTheBars(a,b,true);
				//return a.close - b.close;
			}
			else{
				return sortTheBars(a,b,false);
			}
			//return b.close - a.close;
		};

		historicChartSvg.selectAll(".closeBar")
			.sort(sortItems)
			.transition()
		    .attr("fill", function(d,i) {
				//return "rgb("+(i * 2)+", "+(i * 1)+", " + (i* 1) + ")";
				return "#3f97fe";
			})
			.delay(function (d, i) {
				return i * 20;
			})
			.duration(1000)
			.attr("y", function (d, i) {
				return yScaleHistoricChart(d.close);
			})
			.attr("x", function (d, i) {
				//alert(xScaleHistoricChart(parseDate.parse(d.timeIndex)));
				return xScaleHistoricChart(parseDate.parse(d.timeIndex));
			});
	}

	function initialiseChart(){
		$('#cmf').html("");
		$('#closeDemaChartDiv').html("");
		$('#closePriceDifferenceChartDiv').html("");
		
		historicChartMaxY=d3.max(closeDataArray, function(d) { return d; });
		historicChartMinY=d3.min(closeDataArray, function(d) { return d; });
		var interVal=$scope.$parent.historicChartInterval;
		
		if(interVal == '1M' || interVal == '3M'){
			formatDate = d3.time.format("%e%b| %Y");
		}
		else {
			formatDate = d3.time.format("%b| %Y");
		}
		drawCharts();
		//mouseOver();
	}
	
	function getDatumForTime(time){
		//alert(time.toString() +" type "+(typeof time));
		//time=time.toString();
		//var hoverDate=new Date(time);
		
		var year=time.getFullYear();
		var month=time.getMonth()+1;
		var day=time.getDate();
		if(month<10){
			month="0"+month;
		}
		if(day<10){
			day="0"+day;
		}
		
		var desiredDate=year+"-"+month+"-"+day;
		
		for(var i=0;i<historicChartData.length;i++){
			if(historicChartData[i].timeIndex==desiredDate ){
				//console.error("matched");
				return historicChartData[i];
			}
			else{
//				console.error("date hover "+desiredDate +" : date val "+historicChartData[i].timeIndex);
			}
		}
		
		
	}
	
	var timeAxisSvg;
	function buildTimeAxisForHistoricChart(){
		var heightOfTimeAxisSvg=100;
		timeAxisSvg=d3.selectAll('#timeAxisForHistoricalData').append('svg')
		.attr('width',historicalChartWidth)
		.attr('height',heightOfTimeAxisSvg);
		
		timeAxisSvg.append("g")			// Add the X Axis
			.attr("class", "xAxisHistoryChart")
			.attr("transform", "translate(0," + (heightOfTimeAxisSvg/2) + ")")
			.call(xAxisHistoricCharts);
		
	}
	function redraw(){
		var	closeLine = d3.svg.line()
			.x(function(d) { return xScaleHistoricChart(d[0]); })
			.y(function(d) { return yScaleHistoricChart(d[1]); }).interpolate('basis');
			
		
		
		var demaLine=d3.svg.line()
					  .x(function(d){return xScaleHistoricChart(d[0]);})
					  .y(function(d){return yScaleHistoricChart(d[1]);}).interpolate('basis');
	}
	
	function drawCMFChart(){
		//alert("draw cmf ");
		var cmfChartHeight;
		if($scope.$parent.barChart && $scope.$parent.candleChart){
			cmfChartHeight=(historicalChartHeight/4.5);
		}
		else{
			if(!$scope.$parent.barChart && !$scope.$parent.candleChart){
				cmfChartHeight=(historicalChartHeight);
			}
			else{
				if(!$scope.$parent.candleChart){
					cmfChartHeight=(historicalChartHeight/3.5);
				}
				else{
					cmfChartHeight=(historicalChartHeight/3);
				}
			}
		}
		//var cmfChartHeight=(historicalChartHeight/5);
		var cmfChartSvg = d3.select("#cmf")
            .append("svg:svg")
            .attr("class", "cmChart")
            .attr("width",historicalChartWidth)
            .attr("height",cmfChartHeight+margin.bottom );
		
		var moneyFlowArray=new Array();
		for(var i=0;i<historicChartData.length;i++){
			if(historicChartData[i].cmf != "N/A"){
				moneyFlowArray.push(historicChartData[i].cmf);
			}
		}
		
		moneyFlowArray.sort(function(a,b){
			if(a>b){
				return 1; 
			}
			else if(b>a){
				return -1;
			}
			else{
				return 0;
			}
		});
		var min=moneyFlowArray[0];
		var max=moneyFlowArray[moneyFlowArray.length-1];
		
		
		//var xScaleCmf=d3.scale.linear().range([0, (historicalChartWidth*scalableLimit)]).domain([historicChartData[0].timeIndex1,historicChartData[historicChartData.length-1].timeIndex1]);
		yScaleCmfChart = d3.scale.linear()
		.domain([min,max])
		.range([cmfChartHeight, 0]);
		
		var clipCMF = cmfChartSvg.append("defs").append("svg:clipPath")
		.attr("id", "clip2")
		.append("svg:rect")
		.attr("id", "clip-rect")
		.attr("x", "0")
		.attr("y", "0")
		.attr("width", historicalChartWidth-margin.right)
		.attr("height",cmfChartHeight);	
		
		var cmfClipGrouping=cmfChartSvg.append('g').attr("clip-path", "url(#clip1)").attr("transform", "translate(0," + (margin.top) + ")");
		
		area = d3.svg.area()
			.x(function (d) {
				return xScaleHistoricChart(parseDate.parse(d.timeIndex));
			})
			.y0(yScaleCmfChart(0))
			.y1(function (d) {
				
				if(d.cmf!="N/A"){
					
					return yScaleCmfChart(d.cmf);
				}else{
					
					return yScaleCmfChart(0);
				}
				
			})
			.interpolate("basis");
		var gradient = cmfChartSvg.append("svg:defs")
		.append("svg:linearGradient")
		.attr("id", "gradient")
		.attr("x1", "0%")
		.attr("y1", yScaleCmfChart(min))
		.attr("x2", "100%")
		.attr("y2", yScaleCmfChart(max))
		.attr("gradientUnits", "userSpaceOnUse");
		
		gradient
            .append("stop")
            .attr("offset", "0")
            .attr("stop-color", "#b41923");
        gradient
            .append("stop")
            .attr("offset", "0.25")
            .attr("stop-color", "#c74b27");
        gradient
            .append("stop")
            .attr("offset", "0.5")
            .attr("stop-color", "#f9cd32");

        gradient
            .append("stop")
            .attr("offset", ".75")
            .attr("stop-color", "#5fbf2c");
        gradient
            .append("stop")
            .attr("offset", "1")
            .attr("stop-color", "#15b328");

		cmfClipGrouping.append("path")
                    .data([historicChartData])
					.attr("class","money-flow-area ")
					.style('fill','url(#gradient)')
                    .attr("d", function(d){ return area(d)});
		
		turningPoints = [0];
		
        cmfChartSvg.append("text")
            .attr("class", "yrule")
            .attr("x", (historicalChartWidth))
            .attr("y", yScaleCmfChart(0)+margin.top)
            .attr("dy", 0)
            .attr("dx", 0)
            .attr("text-anchor", "end")
            .text("0.00");
		
		function sign(x) {
            return x > 0 ? 1 : x < 0 ? -1 : 0;
        }

	}
	
	function redrawCmf(){
		$('.money-flow-area').html('');
		var alternatingStyle = historicChartData[0].cmf > 0;
        var lastMidPointTimeStamp;
		turningPoints = [0];
		function sign(x) {
            return x > 0 ? 1 : x < 0 ? -1 : 0;
        }
		
        $(historicChartData).each(function (index, datum) {
            if (index > 0) {
				if(!isNaN(historicChartData[index - 1].cmf) && !isNaN(datum.cmf)){
                if (sign(historicChartData[index - 1].cmf) != sign(datum.cmf) && datum.cmf != 0) {
                    turningPoints.push(index);
                }
            }
				else{
					turningPoints.push(index);
				}
            }
        });
		
        $(turningPoints).each(function (index, tp0) {
            var subset;
            if (index != turningPoints.length - 1) {
                var tp1 = turningPoints[index + 1];
				//console.log("INDEX "+index + "index next  "+(index+1));
                subset = historicChartData.slice(tp0, tp1);
                
				var mFlow;
				if(tp1!=tp0 && tp1!=historicChartData.length-1){
					// < data.length - 1){
					mFlow=0;
				}
				else{
					if(historicChartData[tp1].cmf=="N/A"){
						mFlow=0;
					}
					else{
						mFlow=historicChartData[tp1].cmf;
					}
				}
				
				if(historicChartData[tp0].cmf == "N/A"){
					alternatingStyle=historicChartData[tp1].cmf >= 0;
				}
				else{	
              	
                  alternatingStyle=historicChartData[tp0].cmf >= 0;
				}
                var area = d3.svg.area()
                    .x(function (d) {
						return xScaleHistoricChart(parseDate.parse(d.timeIndex));
                    })
                    .y0(yScaleCmfChart(0))
                    .y1(function (d) {
						
						if(d.cmf!="N/A"){
							
                        return yScaleCmfChart(d.cmf);
						}else{
							
							return yScaleCmfChart(0);
						}
                        
                    })
                    .interpolate("basis");

                d3.selectAll(".money-flow-area ")
                    .datum(subset)
					.attr("d", area(subset));	
			}
		});	
	}
	
	function drawCloseDifferenceChart(){
		var changeCloseChartHeight;
		
		if($scope.$parent.barChart && $scope.$parent.areaChart){
			changeCloseChartHeight=(historicalChartHeight/1.7);
		}
		else{
			if(!$scope.$parent.barChart && !$scope.$parent.areaChart){
				changeCloseChartHeight=historicalChartHeight;
			}
			else{
				if(!$scope.$parent.barChart){
					changeCloseChartHeight=(historicalChartHeight/1.5);
				}
				else if(!$scope.$parent.areaChart){
					changeCloseChartHeight=(historicalChartHeight/1.5);
				}
				else{
					changeCloseChartHeight=(historicalChartHeight/2);
				}
			}
		}
		
	   var minYCloseDifference=	d3.min(historicChartData.map(function(d){
			return d.close;
	   }));
	   minYCloseDifference=minYCloseDifference-1;
	   var maxYCloseDifference=d3.max(historicChartData.map(function(d){
			return d.close;
	   }));
	   maxYCloseDifference=maxYCloseDifference+1;
	   
	   yScaleCloseDifference=d3.scale.linear().range([(changeCloseChartHeight), 0]).domain([minYCloseDifference,maxYCloseDifference]).nice();	
	   
		
	   //draw close line difference rect
	   
	   closeDifferenceSvg=d3.select('#closePriceDifferenceChartDiv').append('svg')
							.attr('width',historicalChartWidth)
							.attr('height',changeCloseChartHeight+margin.bottom).attr('cursor','move')
							.append('g').attr('transform','translate(0,-50)');
		
		var clipCloseDifference = closeDifferenceSvg.append("defs").append("svg:clipPath")
		.attr("id", "clip1")
		.append("svg:rect")
		.attr("id", "clip-rect")
		.attr("x", "0")
		.attr("y", "0")
		.attr("width", historicalChartWidth-margin.right)
		.attr("height",changeCloseChartHeight);	
		
		// Add the Y Axis
		var ticksArray=[];
		var min=d3.min(closeDataArray.map(function(d){
		
			return d.close;
		}));
		
		var max=d3.max(closeDataArray.map(function(d){
		
			return d.close;
		}));
		var midTickVal=(closeDataArray[0]+closeDataArray[closeDataArray.length-1])/2;
		
		ticksArray.push(closeDataArray[0]);
		ticksArray.push(midTickVal);
		ticksArray.push(closeDataArray[closeDataArray.length-1]);	
		
		//alert("val "+closeDataArray[closeDataArray.length/2]+" val"+Math.floor(closeDataArray.length/2));
		var yAxiscloseDifference= d3.svg.axis().scale(yScaleCloseDifference)
		.orient("right").tickValues(ticksArray).tickFormat(function(d) { return "-"+ d;});
		//alert(margin.right);
		closeDifferenceSvg.append("g")			// Add the Y Axis
			.attr("id", "yAxisCloseDifference")
			.attr('transform','translate('+(historicalChartWidth-margin.right)+',0)')
			.call(yAxiscloseDifference);
		//xscale
		
		var cliping=	closeDifferenceSvg.append('g').attr("clip-path", "url(#clip1)");
		
	   cliping.selectAll('.closePriceDifferenceRect')
	   .data(historicChartData)
	   .enter()
	   .append('image')
	  // .attr("clip-path", "url(#clip1)")
	  
	   .attr('class',"closePriceDifferenceRect")
	   .attr("xlink:href", function(d,i){ 
			//console.log("image "+d.image);
			if(i== 0){
				return "";
			}
			else{
				if(d.close>historicChartData[i-1].close){
					return "greencandle.png";
				}
				else{
					return "redcandle.png";
				}
			}
		})
	   .attr('x',function(d,i){
			if(i==0){
				return 0;
			}
			else{
				
				return xScaleHistoricChart(parseDate.parse(historicChartData[i].timeIndex));
			}
	   })
	   .attr('y',function(d,i){
			if(i==0){
				return 0;
			}
			else{
				return yScaleCloseDifference(d.close);
			}
	   })
	   .attr('width',function(d,i){
			return ((historicalChartWidth*scalableLimit-historicalChartWidth)/historicChartData.length);
			
	   })
	   
	   .attr('height','0')
	   .transition()
	   .duration(1000)
	   .attr('height',function(d,i){
			if(i==0){
				return 0;
			}
			else{
				return Math.abs(yScaleCloseDifference(d.close)-yScaleCloseDifference(historicChartData[i-1].close));
			}
	   });
	
	}
	function generateXScale(){
		xMin=d3.min(dateArray.map( function(d) { return parseDate.parse(d);}));
		xMax=d3.max(dateArray.map(function(d) { return parseDate.parse(d);}));
		xScaleHistoricChart=d3.time.scale().range([0, (historicalChartWidth*scalableLimit)]).domain([xMin,xMax]);
		
		xAxisHistoricCharts = d3.svg.axis().scale(xScaleHistoricChart)
		.orient("bottom").ticks(10).tickFormat(formatDate);
		
	}
	function drawXAxis(){
		
		//var totalChartHeight=$('#closePriceDifferenceChartDiv').height();//$('#cmf').height()+$('#closeDemaChartDiv').height()+$('#closePriceDifferenceChartDiv').height();
		$('#timeAxisForHistoricalData').html('');
		
		d3.select('#timeAxisForHistoricalData')
		.append('svg')
		.attr('width',historicalChartWidth)
		.attr('height',50).append("g")
		.attr('id','xAxisCloseDifference')
		//.attr("transform", "translate(0," + (totalChartHeight-23) + ")")
		.attr("clip-path", "url(#clip1)")
		.call(xAxisHistoricCharts);
		/*
		closeDifferenceSvg.append("g")
		.attr('id','xAxisCloseDifference')
		.attr("transform", "translate(0," + (totalChartHeight-23) + ")")
		.attr("clip-path", "url(#clip1)")
		.call(xAxisHistoricCharts);
		*/
	}
	
	function drawCloseDemaChart(){
		var closeDemaChartHeight;
		//var closeDemaChartHeight=(historicalChartHeight/5);
		if($scope.$parent.areaChart && $scope.$parent.candleChart){
			closeDemaChartHeight=(historicalChartHeight/5);
		}
		else{
			if(!$scope.$parent.areaChart && !$scope.$parent.candleChart){
				closeDemaChartHeight=(historicalChartHeight);
			}
			else{
				if(!$scope.$parent.candleChart){
					closeDemaChartHeight=(historicalChartHeight/1.5);
				}
				else{
					closeDemaChartHeight=(historicalChartHeight/3);
				}
				
			}
		}
		
		if(d3.max(closeDataArray, function(d) { return d; })>d3.max(demaDataArray, function(d) { return d; })){
			historicChartMaxY=d3.max(closeDataArray, function(d) { return d; });
		}
		else{
			historicChartMaxY=d3.max(demaDataArray, function(d) { return d; });
			
		}
		
		
		if(d3.min(closeDataArray, function(d) { return d; })<d3.min(demaDataArray, function(d) { return d; })){
			historicChartMinY=d3.min(closeDataArray.map(function(d) { return d; }));
		}
		else{
			historicChartMinY=d3.min(demaDataArray.map(function(d) { return d; }));
		}
		var tickMin=historicChartMinY;
		//fhistoricChartMinY=historicChartMinY-20;
		
		yScaleHistoricChart=d3.scale.linear().range([(closeDemaChartHeight), 0]).domain([historicChartMinY,historicChartMaxY]).nice();
		console.log("min y "+historicChartMinY);	
		
		//panningAndZooming=d3.behavior.zoom().x(xScaleHistoricChart).scaleExtent([1, 8]).on("zoom", zoom);					
		
		var closeDemaTicksArray=[];
		closeDemaTicksArray.push(tickMin);
		closeDemaTicksArray.push(historicChartMaxY)
		var r=(historicChartMaxY+tickMin)/2;
		closeDemaTicksArray.push(r);
		
		//MARKING TICKS 6 FOR SPACING AMONG THEM
		yAxisHistoricChart= d3.svg.axis().scale(yScaleHistoricChart)
		.orient("right").tickValues(closeDemaTicksArray).tickFormat(function(d) { return "-"+ d;});
		
		// Define the line
		
		demaLine=d3.svg.line()
					  .x(function(d){return xScaleHistoricChart(parseDate.parse(d.timeIndex));})
					  .y(function(d){return yScaleHistoricChart(d.dema);}).interpolate('cardinal');
		
		//d3.select('#historicalDataChart').call(panningAndZooming)
		
		historicChartSvg=d3.select('#closeDemaChartDiv').append('svg')
							.attr('width',historicalChartWidth)
							.attr('height',(closeDemaChartHeight+margin.bottom+10)).attr('cursor','move')
							.append('g').attr("transform", "translate(0,10 )");
		
		
		var clip = historicChartSvg.append("defs").append("svg:clipPath")
		.attr("id", "clip1")
		.append("svg:rect")
		.attr("id", "clip-rect")
		.attr("x", "0")
		.attr("y", "0")
		.attr("width", historicalChartWidth-margin.right)
		.attr("height",closeDemaChartHeight);
	
		// Add the Y Axis
		historicChartSvg.append("g")			// Add the Y Axis
			.attr("id", "yAxisHistoryChart")
			.attr('transform','translate('+(historicalChartWidth-margin.right)+',0)')
			.call(yAxisHistoricChart);			  
		
		
		var clippingPath=historicChartSvg.append("g").attr("clip-path", "url(#clip1)");
		
	    clippingPath.selectAll('.closeBar').data(historicChartData).enter().append('rect')
					.attr('class','closeBar')
					.attr('x',function(d){
						return xScaleHistoricChart(parseDate.parse(d.timeIndex));
					})
					.attr('y',function(d){
						return yScaleHistoricChart(d.close);
					})
					.attr('width',function(d){
						return ((historicalChartWidth*scalableLimit-historicalChartWidth)/historicChartData.length);
					})
					.attr('fill','white')
					.attr('height','0')
					.transition()
					.duration(1000)
					.attr('fill',function(d,i){
								return "#3f97fe";
						//return "rgb("+((i+1) * 1)+", "+((i+1)  * 2)+", " + ((i+1)  * 10) + ")";
					})	
					.attr('height',function(d){
						try{
						//console.log(Math.abs(yScaleHistoricChart(d.close)-yScaleHistoricChart(historicChartMinY)));
						//alert("close current "+yScaleClose(d.close)+" close min "+yScaleClose(closeMin));
						return Math.abs(yScaleHistoricChart(d.close)-yScaleHistoricChart(historicChartMinY));
						}
						catch(err){
						console.error("current close "+d.close +"  min close "+historicChartMinY);
							return 0;
						}
					});
					
	   clippingPath.append('path')
	   .attr('class','historicLineDema')
	   .attr('d',demaLine(historicChartData))
	   .attr('fill','none');
	}
	var pos={};
	$scope.showHistoricChartToolTip=false;
	/*
	function mouseOver(){
		$("#historicalDataChart").mouseover("mousemove", function (e) {
			var x;
			if(e.offsetX != undefined){
				x = e.offsetX;
			}
			else{
				x=e.pageX-$('#historicalDataChart').offset().left
			}
			
			left = x + this.offsetLeft;
			var datum = getDatumForTime(xScaleHistoricChart.invert(left));
			//console.log("left "+left +"    width "+(historicalChartWidth*scalableLimit-historicalChartWidth) +" offset "+$('#historicalDataChart').offset().left +" offset y "+e.offsetY);
			if(datum && (left-($('#historicalDataChart').offset().left)/1.5)<(historicalChartWidth*scalableLimit-historicalChartWidth)){
				
				$scope.showHistoricChartToolTip=true;
				$('#timeValue').html(datum.timeIndex+", "+datum.close+", "+datum.dema+", "+datum.cmf);
				//console.log("show tool tip ");
				$scope.$apply();
				
			}
			else{
				$scope.showHistoricChartToolTip=false;
				//console.log("dont show ");
				$scope.$apply();
			}
			var topVal;
			if((e.offsetY-350)<0){
				topVal=e.offsetY-350;
			}
			else{
				topVal=e.offsetY;
			}
			$('#dataPanel').css('margin-left',x);
			$('#dataPanel').css('margin-top',topVal);
					
		});
	}
	
	*/
	
	function getHistoricData(){
		
		if($scope.symbol){
			$scope.$parent.symbol=$scope.$parent.symbol.toUpperCase();
		}
		else{
			$scope.$parent.symbol='AAPL';
		}
		var interVal=$scope.$parent.historicChartInterval;
		var startDate;
		var endDate;
		var lastIndex
		if(interVal.indexOf("M")!=-1){
			lastIndex=interVal.indexOf("M");
			interVal=interVal.substring(0,lastIndex);
			startDate=getDate('start',interVal,true);
			
		}
		else {
			lastIndex=interVal.indexOf("Y");
			interVal=interVal.substring(0,lastIndex);
			startDate=getDate('start',interVal,false);
		}
		
		//alert(interVal);
		endDate=getDate('end','',false);
		
		$.ajax({
			type: "GET",
			//url: "http://app.chaikinpowertools.com/CPTRestSecure/app/sessionless/getPowerTrendChartData?symbol="+ symbol+"&startDate="+startDate+"&endDate="+endDate,          
			url:"http://app.chaikinpowertools.com/CPTRestSecure/app/sessionless/getCMFChartData?symbol="+$scope.$parent.symbol+"&startDate="+startDate+"&endDate="+endDate+"&=00000",          
			dataType:'json',
			crossDomain: true,
			async: true,
		
			success: function(data,status){
				historicChartData=[];
				closeDataArray=data.close_price;
				dateArray=data.calculations_date;
				demaDataArray=data.dema;
				cmfDataArray=data.cmf;
				//alert('cmf '+cmfDataArray.length);
				//alert(closeDataArray.length +"  "+dateArray.length +" "+demaDataArray.length);
				for(var i=0;i<dateArray.length;i++){
					historicChartData.push({'close':closeDataArray[i],'dema':demaDataArray[i],'timeIndex':dateArray[i],'cmf':cmfDataArray[i],'timeIndex1':i});
				}
				initialiseChart();
			},
			error:function(data,status){
				alert('failure ');
			}
		});
	}
	
	function getDate(dateType,interVal,interValInMonth){
		var jsonMonthDayMap=JSON.parse('{"1":"31","3":"93","6":"186"}');
		var jsonMapYear=JSON.parse('{"1":"365"}');
		var todayDate=new Date();
		var dateValue;
		var months = new Array('01','02','03','04','05','06','07','08','09','10','11','12');
		if(dateType=="start"){
			if(interValInMonth){
				interVal=parseInt(interVal);
				todayDate= new Date(todayDate.getTime() -parseInt(jsonMonthDayMap[interVal]) *24*60*60*1000);
			}
			else{
				todayDate= new Date(todayDate.getTime() -parseInt(jsonMapYear[interVal]) *24*60*60*1000);
			}
			
		}
		var date = ((todayDate.getDate()<10) ? "0" : "")+ todayDate.getDate();
		dateValue =  todayDate.getFullYear()+"-" +months[todayDate.getMonth()] + "-" + date;
		return dateValue;
		
	}
	
	function getYearInInteger(number) {
		return (number < 1000) ? number + 1900 : number;
	}
	
	function zoom() {
		var t = panningAndZooming.translate(),
		tx = t[0],
		ty = t[1];

		tx = Math.min(tx, 0);
		tx = Math.max(tx, historicalChartWidth -( scalableLimit*historicalChartWidth) );
		panningAndZooming.translate([tx, ty]);
		 //panningAndZooming.translate([tx, d3.event.translate[1]]);
		 //if(d3.event.translate[0] > xScaleHistoricChart(xMax)) {
		d3.select("#xAxisCloseDifference").call(xAxisHistoricCharts);
		//historicChartSvg.select("yAxisHistoryChart").call(yAxisHistoricChart);
		//historicChartSvg.select(".historicLineClose").attr('d',closeLine(historicChartData));
		historicChartSvg.select(".historicLineDema").attr('d',demaLine(historicChartData));
		d3.selectAll('.closePriceDifferenceRect').data(historicChartData)
		.attr('x',function(d){ //console.log("update rect");
		return xScaleHistoricChart(parseDate.parse(d.timeIndex));})
		.attr('y',function(d){ return yScaleCloseDifference(d.close);});
		
		d3.selectAll('.closeBar').data(historicChartData)
					.attr('x',function(d){
						return xScaleHistoricChart(parseDate.parse(d.timeIndex));
					})
					.attr('y',function(d){
						return yScaleHistoricChart(d.close);
					});
		d3.selectAll('.money-flow-area ').data([historicChartData]).attr('d',function(d){return area(historicChartData);});
		console.log('clicked ');
		
	
	} 

});